<!-- SOCIAL MEDIA + SEARCH -->
<div>
            	
  	<div class="search">
		<form method="post" action="<?php echo $_SERVER['PHP_SELF']; ?>">
			<fieldset>
				<input type="text" class="field" name="s" value="" style="float: left; margin-right: 10px;"/>
				<input type="submit" class="button" name="send" value="Search" />
			</fieldset>
		</form>
	</div>
							
</div>
<!-- /SOCIAL MEDIA + SEARCH -->